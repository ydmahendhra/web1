# Implementation Plan: Phoenix Tech Solutions - Branding, Security, Cleanup & Assignment Emails

Transform the application into the official **Phoenix Tech Solutions** project and intern management platform, featuring the official Phoenix Tech Solutions logo, expanded Software & Hardware internship designations, searchable multi-select skills and interest domains, strict two-admin security, clean production database wipe of all demo records, and automated project assignment email dispatch.

## User Review Required

> [!IMPORTANT]
> **Database Cleanup & Admin Security**: All demonstration Interns, Projects, Assignments, Reports, and Notifications will be permanently removed from MongoDB. Only the **two authorized Admin accounts** (`PTS-CEO-001` - Y D Mahendhra and `PTS-COO-001` - P Praveen Kumar) will be preserved with their configured credentials (`ydm@1962`).
> **Email Notifications**: Email dispatch will use Nodemailer with environment SMTP credentials (`SMTP_HOST`, `SMTP_PORT`, `SMTP_USER`, `SMTP_PASS`, `SMTP_FROM`). When SMTP credentials are not yet set in `.env`, emails will be automatically logged to the new MongoDB `EmailLog` collection and displayed in an Admin Email Activity Drawer for delivery preview and verification.

---

## Proposed Changes

### 1. Company Branding & Official Logo Integration
- **Logo Asset**: Integrate the official logo at `/public/assets/aistudio/image_c321df86.png` (served at `/assets/aistudio/image_c321df86.png`).
- **Global Branding Update**:
  - Replace all occurrences of "NexusProject" and legacy names with **Phoenix Tech Solutions**.
  - Update `index.html` title to `Phoenix Tech Solutions - Project & Intern Management System` and meta tags.
  - Update `metadata.json` app name and description.
  - Brand header, login portal, admin sidebar, intern sidebar, dashboard headers, footers, and modal titles with Phoenix Tech Solutions and the official logo.

### 2. Intern Schema & Customization Options (Software & Hardware)
- **`server/models/Intern.ts`**:
  - Update schema with `designation`, `areaOfInterest: [String]`, `technicalSkills: [String]`, `customInterests: [String]`, `customSkills: [String]`.
- **`src/types/index.ts` & `src/constants/internshipOptions.ts`**:
  - Define the 20 pre-configured role titles (Software Development Intern, Hardware Development Intern, Embedded Systems, VLSI, IoT, AI & ML, Robotics, etc.) plus custom designation entry.
  - Categorized **Area of Interest** options (Software & Development, AI & Data, Hardware & Electronics, Security & Networking, Cloud & Infrastructure, Design, Business & Other) with searchable multi-select component.
  - Categorized **Technical Skills** options (Languages, Frontend, Backend, Databases, Hardware & Embedded, AI/ML, Cyber Security, Cloud/DevOps, Design tools) with searchable multi-select component.
- **Frontend Form Upgrades (`AddInternModal.tsx`, `EditInternModal.tsx`, `InternProfileModal.tsx`, `InternManagement.tsx`)**:
  - Implement reusable `SearchableMultiSelect` component with chips, category grouping, search filter, and custom tag addition.
  - Render designations, technical skills badges, and areas of interest in intern cards and detail views.

### 3. Strict Admin Access Control & Password Privacy
- **`server/services/seedService.ts`**:
  - Strictly enforce that only the **two authorized Admin accounts** exist in the database:
    - **Admin 1**: `PTS-CEO-001` (`Y D Mahendhra`, `mahendhra2005@gamil.com`, username `mahendhra`, password `ydm@1962`, CEO).
    - **Admin 2**: `PTS-COO-001` (`P Praveen Kumar`, `praveenpraba399@gamil.com`, username `praveen`, password `ydm@1962`, COO).
  - Explicitly delete all other admin records from MongoDB.
- **`server/routes/authRoutes.ts` & `adminRoutes.ts`**:
  - Disallow any endpoint from creating additional admin accounts.
  - Enforce `.select('-passwordHash')` on all queries so hashes are never sent over the wire or logged.
  - Passwords never displayed or exported anywhere in the application.

### 4. Complete Demo Data Cleanup
- **`server/services/cleanupService.ts`**:
  - Create and run an atomic database cleanup routine on server startup:
    - Wipe all demo Interns (`INT-2024-01` through `INT-2024-04`).
    - Wipe all demo Projects (`PRJ-9010`, `PRJ-9022`, `PRJ-9035`, etc.).
    - Wipe all demo Project Assignments (`ASG-101` through `ASG-107`).
    - Wipe all demo Reports (`REP-501` through `REP-505`).
    - Wipe all demo Notifications and demo GridFS files.
    - Preserve strictly Admin 1 and Admin 2 with full privileges.
  - Result: A pristine, operational workspace ready for real organizational entries.

### 5. Automated Project Assignment Email System
- **`server/models/EmailLog.ts`**:
  - Create model to track email delivery history: `emailId`, `recipientEmail`, `recipientName`, `internId`, `projectId`, `projectName`, `subject`, `status` (`sent` | `logged_preview` | `failed`), `errorDetails`, `sentAt`, `assignedBy`.
- **`server/services/emailService.ts`**:
  - Build responsive branded HTML email template featuring Phoenix Tech Solutions logo, assignment details (Intern Name, ID, Project Name, ID, Description, Deadline, Assigned By), and portal login link.
  - Auto-dispatch individual emails to each assigned intern upon project assignment.
  - Support live SMTP delivery when `SMTP_HOST` is configured in environment variables.
  - Fallback to MongoDB-backed delivery logging and preview when SMTP credentials are pending.
- **`server/routes/assignmentRoutes.ts` & `emailRoutes.ts`**:
  - Trigger email dispatch automatically when Admin assigns interns.
  - Expose API endpoints for delivery history and manual email re-dispatch.
- **Admin UI Integration**:
  - Add an "Email Delivery History" modal/drawer in Project Management so Admins can verify email dispatches in real-time.

### 6. Excel Export & UI Consistency
- **`server/routes/exportRoutes.ts`**:
  - Update ExcelJS export logic to include `Intern Designation`, `Area of Interest`, and `Technical Skills`.
  - Exclude all password or sensitive authentication fields.
- **`src/components/auth/AuthPortal.tsx`**:
  - Brand with Phoenix Tech Solutions and official logo.
  - Update quick test credentials toggle to display only Admin 1 (CEO) and Admin 2 (COO).

---

## Verification Plan

### Automated Verification
- Run `compile_applet` to confirm zero TypeScript compilation errors.
- Run `npm run build` or Vite bundle verification.

### Functional Verification
1. **Branding & Logo**: Verify Phoenix Tech Solutions name and logo appear cleanly on Login, Admin Sidebar, Intern Sidebar, Navbar, and Footer.
2. **Admin Authentication**:
   - Log in with Admin 1 (`PTS-CEO-001` / `ydm@1962` or `mahendhra2005@gamil.com`).
   - Log in with Admin 2 (`PTS-COO-001` / `ydm@1962` or `praveenpraba399@gamil.com`).
   - Verify non-authorized accounts are rejected.
3. **Database Cleanup**: Verify Intern, Project, Assignment, and Report lists start completely empty with clean empty states.
4. **Intern Creation**:
   - Register a Software Development Intern and a Hardware Development Intern.
   - Test searchable multi-select for Area of Interest and Technical Skills with custom values.
   - Verify fields persist in MongoDB and display in profile cards.
5. **Project Assignment & Automatic Email**:
   - Create a project and assign the newly created intern.
   - Verify automated email notification is triggered and recorded in MongoDB `EmailLog`.
   - Open the Email Delivery History view to verify recipient, timestamp, and HTML template formatting.
6. **Excel Export**: Export Interns to Excel and verify Designation, Skills, and Interests columns are populated without any password exposure.
