import { Router, Request, Response } from 'express';
import bcrypt from 'bcryptjs';
import { Admin } from '../models/Admin';
import { Intern } from '../models/Intern';
import { generateToken, authenticate } from '../middleware/auth';

const router = Router();

// POST /api/auth/admin/login
router.post('/admin/login', async (req: Request, res: Response) => {
  try {
    const { identifier, password } = req.body;
    if (!identifier || !password) {
      return res.status(400).json({ success: false, message: 'Admin ID/Email and password are required.' });
    }

    const cleanId = identifier.trim().toLowerCase();
    const admin = await Admin.findOne({
      $or: [
        { email: cleanId },
        { username: cleanId },
        { adminId: cleanId.toUpperCase() },
        { adminId: identifier.trim() },
      ],
    });

    if (!admin) {
      return res.status(401).json({ success: false, message: 'Invalid Admin credentials.' });
    }

    if (admin.accountStatus !== 'active') {
      return res.status(403).json({ success: false, message: 'This Admin account has been deactivated.' });
    }

    const isMatch = await bcrypt.compare(password, admin.passwordHash);
    if (!isMatch) {
      return res.status(401).json({ success: false, message: 'Incorrect Admin password.' });
    }

    const token = generateToken({
      id: admin.adminId,
      username: admin.username,
      email: admin.email,
      role: 'admin',
      name: admin.name,
    });

    return res.json({
      success: true,
      message: 'Admin authenticated successfully.',
      token,
      user: {
        id: admin.adminId,
        adminId: admin.adminId,
        name: admin.name,
        username: admin.username,
        email: admin.email,
        role: 'admin',
        designation: admin.designation,
        department: admin.department,
        contactNumber: admin.contactNumber,
        contactInfo: admin.contactInfo,
        profileImage: admin.profileImage,
      },
    });
  } catch (err: any) {
    console.error('Admin login error:', err);
    return res.status(500).json({ success: false, message: 'Server error during Admin authentication.' });
  }
});

// POST /api/auth/intern/login
router.post('/intern/login', async (req: Request, res: Response) => {
  try {
    const { identifier, password } = req.body;
    if (!identifier || !password) {
      return res.status(400).json({ success: false, message: 'Intern ID/Username and password are required.' });
    }

    const cleanId = identifier.trim().toLowerCase();
    const intern = await Intern.findOne({
      $or: [
        { internId: cleanId.toUpperCase() },
        { username: cleanId },
        { email: cleanId },
      ],
    });

    if (!intern) {
      return res.status(401).json({ success: false, message: 'Intern account not found.' });
    }

    if (intern.accountStatus !== 'active') {
      return res.status(403).json({
        success: false,
        message: 'This Intern account is inactive. Please contact your organization administrator.',
      });
    }

    const isMatch = await bcrypt.compare(password, intern.passwordHash);
    if (!isMatch) {
      return res.status(401).json({ success: false, message: 'Incorrect Intern password.' });
    }

    const token = generateToken({
      id: intern.internId,
      username: intern.username,
      email: intern.email,
      role: 'intern',
      name: intern.fullName,
    });

    return res.json({
      success: true,
      message: 'Intern authenticated successfully.',
      token,
      user: {
        id: intern.internId,
        internId: intern.internId,
        fullName: intern.fullName,
        username: intern.username,
        email: intern.email,
        role: 'intern',
        phoneNumber: intern.phoneNumber,
        collegeName: intern.collegeName,
        department: intern.department,
        degree: intern.degree,
        skills: intern.skills,
        designation: intern.designation,
        profileImage: intern.profileImage,
        internshipStartDate: intern.internshipStartDate,
        internshipEndDate: intern.internshipEndDate,
      },
    });
  } catch (err: any) {
    console.error('Intern login error:', err);
    return res.status(500).json({ success: false, message: 'Server error during Intern authentication.' });
  }
});

// POST /api/auth/logout
router.post('/logout', (_req: Request, res: Response) => {
  return res.json({ success: true, message: 'Logged out successfully.' });
});

// GET /api/auth/me
router.get('/me', authenticate, async (req: Request, res: Response) => {
  try {
    if (!req.user) {
      return res.status(401).json({ success: false, message: 'Not authenticated.' });
    }

    if (req.user.role === 'admin') {
      const admin = await Admin.findOne({ adminId: req.user.id }).select('-passwordHash');
      if (!admin) return res.status(404).json({ success: false, message: 'Admin not found.' });
      return res.json({ success: true, role: 'admin', user: admin });
    } else {
      const intern = await Intern.findOne({ internId: req.user.id }).select('-passwordHash');
      if (!intern) return res.status(404).json({ success: false, message: 'Intern not found.' });
      return res.json({ success: true, role: 'intern', user: intern });
    }
  } catch (err: any) {
    return res.status(500).json({ success: false, message: err.message });
  }
});

export default router;
