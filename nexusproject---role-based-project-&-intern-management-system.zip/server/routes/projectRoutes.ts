import { Router, Request, Response } from 'express';
import { Project } from '../models/Project';
import { ProjectAssignment } from '../models/ProjectAssignment';
import { Intern } from '../models/Intern';
import { requireAdmin, authenticate } from '../middleware/auth';

const router = Router();

// GET /api/projects - list all projects
router.get('/', authenticate, async (req: Request, res: Response) => {
  try {
    const { category, status, search } = req.query;
    const filter: any = {};

    if (category && category !== 'All') {
      filter.category = category;
    }
    if (status && status !== 'All') {
      filter.projectStatus = status;
    }
    if (search) {
      const q = search.toString();
      filter.$or = [
        { projectName: { $regex: q, $options: 'i' } },
        { projectId: { $regex: q, $options: 'i' } },
        { description: { $regex: q, $options: 'i' } },
      ];
    }

    const projects = await Project.find(filter).sort({ createdAt: -1 }).lean();
    const activeAssignments = await ProjectAssignment.find({ assignmentStatus: 'active' }).lean();

    // Map assigned intern IDs into each project
    const projectsWithInterns = projects.map((p: any) => {
      const assigned = activeAssignments
        .filter((a: any) => a.projectId === p.projectId)
        .map((a: any) => a.internId);
      return {
        ...p,
        id: p.projectId,
        name: p.projectName,
        status: p.projectStatus,
        assignedInternIds: assigned,
      };
    });

    return res.json({ success: true, count: projectsWithInterns.length, projects: projectsWithInterns });
  } catch (err: any) {
    return res.status(500).json({ success: false, message: err.message });
  }
});

// GET /api/projects/:id - get single project
router.get('/:id', authenticate, async (req: Request, res: Response) => {
  try {
    const project = await Project.findOne({
      $or: [{ projectId: req.params.id }, { _id: req.params.id }],
    }).lean();

    if (!project) {
      return res.status(404).json({ success: false, message: 'Project not found.' });
    }

    const assignments = await ProjectAssignment.find({
      projectId: project.projectId,
      assignmentStatus: 'active',
    }).lean();

    const internIds = assignments.map((a: any) => a.internId);
    const assignedInterns = await Intern.find({ internId: { $in: internIds } })
      .select('-passwordHash')
      .lean();

    return res.json({
      success: true,
      project: {
        ...project,
        id: project.projectId,
        name: project.projectName,
        status: project.projectStatus,
        assignedInternIds: internIds,
        assignedInterns,
      },
    });
  } catch (err: any) {
    return res.status(500).json({ success: false, message: err.message });
  }
});

// POST /api/projects - create project (Admin only)
router.post('/', requireAdmin, async (req: Request, res: Response) => {
  try {
    const {
      projectName,
      name,
      description,
      objectives,
      requirements,
      category,
      domainId,
      startDate,
      deadline,
      projectStatus,
      status,
      referenceDocs,
    } = req.body;

    const projName = projectName || name;
    if (!projName || !description || !startDate || !deadline) {
      return res.status(400).json({ success: false, message: 'Missing required project attributes.' });
    }

    const randId = Math.floor(1000 + Math.random() * 9000);
    const projectId = `PRJ-${randId}`;

    const newProject = await Project.create({
      projectId,
      projectName: projName.trim(),
      description,
      objectives: objectives || [],
      requirements: requirements || [],
      category: category || 'Web & Mobile Platforms',
      domainId: domainId || '',
      startDate,
      deadline,
      projectStatus: projectStatus || status || 'Planning',
      progress: 0,
      referenceDocs: referenceDocs || [],
      createdBy: req.user?.id || 'ADM-1001',
    });

    return res.status(201).json({
      success: true,
      message: `Project "${newProject.projectName}" (${projectId}) created successfully.`,
      project: {
        ...newProject.toObject(),
        id: newProject.projectId,
        name: newProject.projectName,
        status: newProject.projectStatus,
        assignedInternIds: [],
      },
    });
  } catch (err: any) {
    return res.status(500).json({ success: false, message: err.message });
  }
});

// PUT /api/projects/:id - update project
router.put('/:id', requireAdmin, async (req: Request, res: Response) => {
  try {
    const updates = { ...req.body };
    if (updates.name && !updates.projectName) updates.projectName = updates.name;
    if (updates.status && !updates.projectStatus) updates.projectStatus = updates.status;

    delete updates.projectId; // preserve immutable ID

    const project = await Project.findOneAndUpdate(
      { $or: [{ projectId: req.params.id }, { _id: req.params.id }] },
      { $set: updates },
      { new: true }
    );

    if (!project) {
      return res.status(404).json({ success: false, message: 'Project not found.' });
    }

    return res.json({
      success: true,
      message: `Project ${project.projectName} updated.`,
      project: {
        ...project.toObject(),
        id: project.projectId,
        name: project.projectName,
        status: project.projectStatus,
      },
    });
  } catch (err: any) {
    return res.status(500).json({ success: false, message: err.message });
  }
});

// DELETE /api/projects/:id - delete project
router.delete('/:id', requireAdmin, async (req: Request, res: Response) => {
  try {
    const project = await Project.findOne({
      $or: [{ projectId: req.params.id }, { _id: req.params.id }],
    });

    if (!project) {
      return res.status(404).json({ success: false, message: 'Project not found.' });
    }

    await Project.deleteOne({ _id: project._id });
    await ProjectAssignment.deleteMany({ projectId: project.projectId });

    return res.json({ success: true, message: `Project ${project.projectName} deleted.` });
  } catch (err: any) {
    return res.status(500).json({ success: false, message: err.message });
  }
});

export default router;
