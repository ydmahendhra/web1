import bcrypt from 'bcryptjs';
import { Admin } from '../models/Admin';
import { Intern } from '../models/Intern';
import { Project } from '../models/Project';
import { ProjectAssignment } from '../models/ProjectAssignment';
import { Report } from '../models/Report';
import { Notification } from '../models/Notification';

export async function seedDatabase() {
  console.log('[Seed] Verifying initial database collections...');

  // 1. Remove legacy demo admin accounts if present
  await Admin.deleteMany({ adminId: { $in: ['ADM-1001', 'ADM-1002', 'ADM-001'] } });

  // Admin 1 - Y D Mahendhra (CEO)
  const admin1Id = process.env.ADMIN1_ID || 'PTS-CEO-001';
  const admin1Name = process.env.ADMIN1_NAME || 'Y D Mahendhra';
  const admin1Username = (process.env.ADMIN1_USERNAME || 'Mahendhra').toLowerCase();
  const admin1Email = (process.env.ADMIN1_EMAIL || 'mahendhra2005@gamil.com').toLowerCase();
  const admin1Password = process.env.ADMIN1_PASSWORD || 'ydm@1962';

  const salt1 = await bcrypt.genSalt(10);
  const hash1 = await bcrypt.hash(admin1Password, salt1);

  const existingAdmin1 = await Admin.findOne({ $or: [{ adminId: admin1Id }, { email: admin1Email }, { username: admin1Username }] });
  if (!existingAdmin1) {
    await Admin.create({
      adminId: admin1Id,
      name: admin1Name,
      username: admin1Username,
      email: admin1Email,
      passwordHash: hash1,
      contactNumber: '+91 98765 43210',
      designation: 'Chief Executive Officer (CEO)',
      department: 'Executive Leadership & Project Operations',
      contactInfo: 'Executive Office · Email: ' + admin1Email,
      role: 'admin',
      accountStatus: 'active',
    });
    console.log(`[Seed] Initialized Admin 1 (CEO): ${admin1Name} (${admin1Id} / ${admin1Email})`);
  } else {
    // Ensure password hash matches current configuration
    existingAdmin1.passwordHash = hash1;
    existingAdmin1.name = admin1Name;
    existingAdmin1.email = admin1Email;
    existingAdmin1.username = admin1Username;
    existingAdmin1.designation = 'Chief Executive Officer (CEO)';
    await existingAdmin1.save();
    console.log(`[Seed] Verified and updated Admin 1 (CEO): ${existingAdmin1.name} (${existingAdmin1.adminId})`);
  }

  // Admin 2 - P Praveen Kumar (COO)
  const admin2Id = process.env.ADMIN2_ID || 'PTS-COO-001';
  const admin2Name = process.env.ADMIN2_NAME || 'P Praveen Kumar';
  const admin2Username = (process.env.ADMIN2_USERNAME || 'Praveen').toLowerCase();
  const admin2Email = (process.env.ADMIN2_EMAIL || 'praveenpraba399@gamil.com').toLowerCase();
  const admin2Password = process.env.ADMIN2_PASSWORD || 'ydm@1962';

  const salt2 = await bcrypt.genSalt(10);
  const hash2 = await bcrypt.hash(admin2Password, salt2);

  const existingAdmin2 = await Admin.findOne({ $or: [{ adminId: admin2Id }, { email: admin2Email }, { username: admin2Username }] });
  if (!existingAdmin2) {
    await Admin.create({
      adminId: admin2Id,
      name: admin2Name,
      username: admin2Username,
      email: admin2Email,
      passwordHash: hash2,
      contactNumber: '+91 98765 43211',
      designation: 'Chief Operating Officer (COO)',
      department: 'Operations & Technical Oversight',
      contactInfo: 'Executive Office · Email: ' + admin2Email,
      role: 'admin',
      accountStatus: 'active',
    });
    console.log(`[Seed] Initialized Admin 2 (COO): ${admin2Name} (${admin2Id} / ${admin2Email})`);
  } else {
    // Ensure password hash matches current configuration
    existingAdmin2.passwordHash = hash2;
    existingAdmin2.name = admin2Name;
    existingAdmin2.email = admin2Email;
    existingAdmin2.username = admin2Username;
    existingAdmin2.designation = 'Chief Operating Officer (COO)';
    await existingAdmin2.save();
    console.log(`[Seed] Verified and updated Admin 2 (COO): ${existingAdmin2.name} (${existingAdmin2.adminId})`);
  }

  // 2. Perform Complete Demo Data Cleanup per Section 7
  console.log('[Cleanup] Performing complete demonstration data wipe for Phoenix Tech Solutions...');
  await Intern.deleteMany({});
  await Project.deleteMany({});
  await ProjectAssignment.deleteMany({});
  await Report.deleteMany({});
  await Notification.deleteMany({});
  await Admin.deleteMany({ adminId: { $nin: [admin1Id, admin2Id] } });

  console.log('[Seed] Database initialization complete: Pristine workspace ready with 2 authorized Admins.');
}

