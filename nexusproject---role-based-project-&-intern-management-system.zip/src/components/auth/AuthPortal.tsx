import React, { useState } from 'react';
import { Shield, Users, GraduationCap, Eye, EyeOff, ArrowRight, Lock, Mail, KeyRound, AlertCircle, Sparkles, Clock, CheckCircle, Terminal, ChevronDown, ChevronUp } from 'lucide-react';
import { useApp } from '../../context/AppContext';

export const AuthPortal: React.FC = () => {
  const { login } = useApp();

  // Selected tab: 'admin' | 'staff' | 'intern'
  const [activeTab, setActiveTab] = useState<'admin' | 'staff' | 'intern'>('admin');

  // Admin form - clean empty initial inputs
  const [adminIdentifier, setAdminIdentifier] = useState('');
  const [adminPassword, setAdminPassword] = useState('');
  const [showAdminPassword, setShowAdminPassword] = useState(false);

  // Intern form - clean empty initial inputs
  const [internIdentifier, setInternIdentifier] = useState('');
  const [internPassword, setInternPassword] = useState('');
  const [showInternPassword, setShowInternPassword] = useState(false);

  // Status & errors
  const [errorMessage, setErrorMessage] = useState('');
  const [successMessage, setSuccessMessage] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  // Test credentials toggle for development testing
  const [showTestCredentials, setShowTestCredentials] = useState(false);

  // Forgot password modal
  const [forgotModalOpen, setForgotModalOpen] = useState(false);
  const [forgotEmail, setForgotEmail] = useState('');
  const [forgotSent, setForgotSent] = useState(false);

  const handleAdminSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage('');
    setIsSubmitting(true);
    try {
      const res = await login('admin', adminIdentifier.trim(), adminPassword);
      if (!res.success) {
        setErrorMessage(res.message);
      }
    } catch (err: any) {
      setErrorMessage(err.message || 'Login failed.');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleInternSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage('');
    setIsSubmitting(true);
    try {
      const res = await login('intern', internIdentifier.trim(), internPassword);
      if (!res.success) {
        setErrorMessage(res.message);
      }
    } catch (err: any) {
      setErrorMessage(err.message || 'Login failed.');
    } finally {
      setIsSubmitting(false);
    }
  };

  const fillTestAdmin1 = () => {
    setActiveTab('admin');
    setAdminIdentifier('mahendhra2005@gamil.com');
    setAdminPassword('ydm@1962');
    setErrorMessage('');
  };

  const fillTestAdmin2 = () => {
    setActiveTab('admin');
    setAdminIdentifier('praveenpraba399@gamil.com');
    setAdminPassword('ydm@1962');
    setErrorMessage('');
  };

  const fillTestIntern = () => {
    setActiveTab('intern');
    setInternIdentifier('INT-2024-01');
    setInternPassword('intern123');
    setErrorMessage('');
  };

  const handleForgotPassword = (e: React.FormEvent) => {
    e.preventDefault();
    if (!forgotEmail) return;
    setForgotSent(true);
    setTimeout(() => {
      setForgotSent(false);
      setForgotModalOpen(false);
      setForgotEmail('');
    }, 2800);
  };

  return (
    <div className="min-h-screen bg-slate-950 flex flex-col justify-between text-slate-100">
      {/* Top Navbar */}
      <header className="border-b border-slate-800 bg-slate-900/60 backdrop-blur-md px-6 py-4">
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          <div className="flex items-center gap-3">
            <img
              src="/assets/aistudio/image_c321df86.png"
              alt="Phoenix Tech Solutions"
              className="w-10 h-10 rounded-xl object-contain shadow-lg shadow-orange-500/20 bg-slate-950 border border-slate-800"
            />
            <div>
              <span className="text-base font-bold tracking-tight text-white block">Phoenix Tech Solutions</span>
              <span className="text-xs text-orange-400 font-medium">
                Enterprise Project & Intern Management System
              </span>
            </div>
          </div>

          <div className="flex items-center gap-2 text-xs text-slate-400">
            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
            <span className="font-medium text-slate-300">System Operational</span>
          </div>
        </div>
      </header>

      {/* Main Authentication Card */}
      <main className="flex-1 flex items-center justify-center p-4 sm:p-6 my-6">
        <div className="w-full max-w-md bg-slate-900 border border-slate-800 rounded-2xl shadow-2xl p-6 sm:p-8 relative">
          
          {/* Header Title with Logo Badge */}
          <div className="text-center mb-6">
            <div className="inline-block p-1 bg-slate-950 rounded-2xl border border-slate-800 shadow-inner mb-3">
              <img
                src="/assets/aistudio/image_c321df86.png"
                alt="Phoenix Tech Solutions"
                className="w-16 h-16 rounded-xl object-contain"
              />
            </div>
            <h1 className="text-xl sm:text-2xl font-bold tracking-tight text-white mb-1.5">
              Phoenix Tech Solutions
            </h1>
            <p className="text-xs text-slate-400">
              Role-Based Access Portal · Select authorization role
            </p>
          </div>

          {/* Role Segmented Switcher */}
          <div className="grid grid-cols-3 p-1 bg-slate-950 border border-slate-800 rounded-xl mb-6">
            <button
              type="button"
              onClick={() => {
                setActiveTab('admin');
                setErrorMessage('');
              }}
              className={`flex flex-col items-center gap-1 py-2.5 px-2 rounded-lg text-xs font-medium transition-all cursor-pointer ${
                activeTab === 'admin'
                  ? 'bg-indigo-600 text-white shadow-md'
                  : 'text-slate-400 hover:text-white hover:bg-slate-800/60'
              }`}
            >
              <Shield className="w-4 h-4" />
              <span>Admin</span>
            </button>

            <button
              type="button"
              onClick={() => {
                setActiveTab('staff');
                setErrorMessage('');
              }}
              className={`flex flex-col items-center gap-1 py-2.5 px-2 rounded-lg text-xs font-medium transition-all cursor-pointer ${
                activeTab === 'staff'
                  ? 'bg-slate-800 text-amber-300 border border-amber-500/30'
                  : 'text-slate-400 hover:text-white hover:bg-slate-800/60'
              }`}
            >
              <Users className="w-4 h-4" />
              <div className="flex items-center gap-1">
                <span>Staff</span>
                <span className="text-[9px] px-1 py-0.2 bg-amber-500/20 text-amber-400 rounded">Soon</span>
              </div>
            </button>

            <button
              type="button"
              onClick={() => {
                setActiveTab('intern');
                setErrorMessage('');
              }}
              className={`flex flex-col items-center gap-1 py-2.5 px-2 rounded-lg text-xs font-medium transition-all cursor-pointer ${
                activeTab === 'intern'
                  ? 'bg-indigo-600 text-white shadow-md'
                  : 'text-slate-400 hover:text-white hover:bg-slate-800/60'
              }`}
            >
              <GraduationCap className="w-4 h-4" />
              <span>Intern</span>
            </button>
          </div>

          {/* Error Message Box */}
          {errorMessage && (
            <div className="mb-5 p-3 rounded-lg bg-rose-950/60 border border-rose-800/80 text-rose-300 text-xs flex items-start gap-2.5">
              <AlertCircle className="w-4 h-4 text-rose-400 shrink-0 mt-0.5" />
              <span className="leading-snug">{errorMessage}</span>
            </div>
          )}

          {/* Success Message Box */}
          {successMessage && (
            <div className="mb-5 p-3 rounded-lg bg-emerald-950/60 border border-emerald-800/80 text-emerald-300 text-xs flex items-start gap-2.5">
              <CheckCircle className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
              <span className="leading-snug">{successMessage}</span>
            </div>
          )}

          {/* TAB 1: ADMIN LOGIN */}
          {activeTab === 'admin' && (
            <form onSubmit={handleAdminSubmit} className="space-y-4">
              <div className="space-y-1.5">
                <label className="block text-xs font-medium text-slate-300">
                  Admin User ID or Email
                </label>
                <div className="relative">
                  <Mail className="w-4 h-4 text-slate-500 absolute left-3 top-3 pointer-events-none" />
                  <input
                    type="text"
                    value={adminIdentifier}
                    onChange={(e) => setAdminIdentifier(e.target.value)}
                    required
                    placeholder="e.g. mahendhra2005@gamil.com or PTS-CEO-001"
                    className="w-full pl-9 pr-3 py-2 bg-slate-950 border border-slate-700 rounded-lg text-sm text-white placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent transition"
                  />
                </div>
              </div>

              <div className="space-y-1.5">
                <div className="flex items-center justify-between">
                  <label className="block text-xs font-medium text-slate-300">
                    Admin Password
                  </label>
                  <button
                    type="button"
                    onClick={() => {
                      setForgotEmail(adminIdentifier);
                      setForgotModalOpen(true);
                    }}
                    className="text-xs text-indigo-400 hover:text-indigo-300 transition-colors cursor-pointer"
                  >
                    Forgot Password?
                  </button>
                </div>
                <div className="relative">
                  <Lock className="w-4 h-4 text-slate-500 absolute left-3 top-3 pointer-events-none" />
                  <input
                    type={showAdminPassword ? 'text' : 'password'}
                    value={adminPassword}
                    onChange={(e) => setAdminPassword(e.target.value)}
                    required
                    placeholder="Enter admin password"
                    className="w-full pl-9 pr-10 py-2 bg-slate-950 border border-slate-700 rounded-lg text-sm text-white placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent transition"
                  />
                  <button
                    type="button"
                    onClick={() => setShowAdminPassword(!showAdminPassword)}
                    className="absolute right-3 top-2.5 text-slate-400 hover:text-slate-200 transition-colors cursor-pointer"
                    aria-label="Toggle password visibility"
                  >
                    {showAdminPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
              </div>

              <button
                type="submit"
                disabled={isSubmitting}
                className="w-full py-2.5 px-4 mt-2 bg-indigo-600 hover:bg-indigo-500 active:bg-indigo-700 disabled:opacity-50 text-white text-sm font-semibold rounded-lg shadow-lg shadow-indigo-600/30 flex items-center justify-center gap-2 transition cursor-pointer"
              >
                <span>{isSubmitting ? 'Authenticating...' : 'Login as Administrator'}</span>
                <ArrowRight className="w-4 h-4" />
              </button>

            </form>
          )}

          {/* TAB 2: STAFF LOGIN (COMING SOON) */}
          {activeTab === 'staff' && (
            <div className="py-6 px-4 text-center space-y-4">
              <div className="w-14 h-14 rounded-2xl bg-amber-500/10 border border-amber-500/30 text-amber-400 flex items-center justify-center mx-auto shadow-inner">
                <Clock className="w-7 h-7" />
              </div>

              <div>
                <h3 className="text-base font-semibold text-white">Staff Portal - Phase 2</h3>
                <p className="text-xs text-slate-400 mt-1 leading-relaxed">
                  The Staff & Mentor coordination module is currently in development for Phase 2 rollout.
                </p>
              </div>

              <div className="p-3 bg-slate-950 border border-slate-800 rounded-lg text-left text-xs space-y-1.5">
                <div className="font-medium text-slate-300">Upcoming Staff Capabilities:</div>
                <ul className="text-slate-400 space-y-1 list-disc list-inside">
                  <li>Departmental mentor oversight</li>
                  <li>Weekly 1-on-1 check-in evaluations</li>
                  <li>Cross-team workload balancing</li>
                </ul>
              </div>

              <div className="pt-2">
                <button
                  type="button"
                  onClick={() => setActiveTab('admin')}
                  className="text-xs text-indigo-400 hover:text-indigo-300 underline underline-offset-4 cursor-pointer"
                >
                  Switch to Admin Portal instead
                </button>
              </div>
            </div>
          )}

          {/* TAB 3: INTERN LOGIN */}
          {activeTab === 'intern' && (
            <form onSubmit={handleInternSubmit} className="space-y-4">
              <div className="space-y-1.5">
                <label className="block text-xs font-medium text-slate-300">
                  Intern User ID or Username
                </label>
                <div className="relative">
                  <KeyRound className="w-4 h-4 text-slate-500 absolute left-3 top-3 pointer-events-none" />
                  <input
                    type="text"
                    value={internIdentifier}
                    onChange={(e) => setInternIdentifier(e.target.value)}
                    required
                    placeholder="e.g. INT-2024-01 or alex.chen"
                    className="w-full pl-9 pr-3 py-2 bg-slate-950 border border-slate-700 rounded-lg text-sm text-white placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent transition tabular-nums"
                  />
                </div>
                <p className="text-[11px] text-slate-500">
                  Intern ID was issued by your administrator during onboarding.
                </p>
              </div>

              <div className="space-y-1.5">
                <div className="flex items-center justify-between">
                  <label className="block text-xs font-medium text-slate-300">
                    Password
                  </label>
                  <button
                    type="button"
                    onClick={() => {
                      setForgotEmail(internIdentifier);
                      setForgotModalOpen(true);
                    }}
                    className="text-xs text-indigo-400 hover:text-indigo-300 transition-colors cursor-pointer"
                  >
                    Forgot Password?
                  </button>
                </div>
                <div className="relative">
                  <Lock className="w-4 h-4 text-slate-500 absolute left-3 top-3 pointer-events-none" />
                  <input
                    type={showInternPassword ? 'text' : 'password'}
                    value={internPassword}
                    onChange={(e) => setInternPassword(e.target.value)}
                    required
                    placeholder="Enter intern account password"
                    className="w-full pl-9 pr-10 py-2 bg-slate-950 border border-slate-700 rounded-lg text-sm text-white placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent transition"
                  />
                  <button
                    type="button"
                    onClick={() => setShowInternPassword(!showInternPassword)}
                    className="absolute right-3 top-2.5 text-slate-400 hover:text-slate-200 transition-colors cursor-pointer"
                    aria-label="Toggle password visibility"
                  >
                    {showInternPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
              </div>

              <button
                type="submit"
                disabled={isSubmitting}
                className="w-full py-2.5 px-4 mt-2 bg-indigo-600 hover:bg-indigo-500 active:bg-indigo-700 disabled:opacity-50 text-white text-sm font-semibold rounded-lg shadow-lg shadow-indigo-600/30 flex items-center justify-center gap-2 transition cursor-pointer"
              >
                <span>{isSubmitting ? 'Authenticating...' : 'Login as Intern'}</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </form>
          )}

          {/* Test Credentials Toggle for Development Testing */}
          <div className="mt-6 pt-4 border-t border-slate-800/80">
            <button
              type="button"
              onClick={() => setShowTestCredentials(!showTestCredentials)}
              className="w-full flex items-center justify-between px-3 py-2 rounded-lg bg-slate-950/60 hover:bg-slate-800/60 border border-slate-800 text-xs text-slate-400 hover:text-slate-200 transition cursor-pointer"
            >
              <span className="flex items-center gap-2">
                <Terminal className="w-3.5 h-3.5 text-indigo-400" />
                <span className="font-medium">Development Test Credentials</span>
              </span>
              {showTestCredentials ? (
                <ChevronUp className="w-3.5 h-3.5 text-slate-500" />
              ) : (
                <ChevronDown className="w-3.5 h-3.5 text-slate-500" />
              )}
            </button>

            {showTestCredentials && (
              <div className="mt-2.5 p-3 rounded-lg bg-slate-950 border border-slate-800/90 text-xs space-y-3">
                {/* Admin 1 */}
                <div className="flex items-center justify-between pb-1.5 border-b border-slate-800/70">
                  <span className="text-[11px] text-slate-300 font-medium">Admin 1: Y D Mahendhra (CEO)</span>
                  <button
                    type="button"
                    onClick={fillTestAdmin1}
                    className="text-[11px] font-semibold text-indigo-400 hover:text-indigo-300 transition cursor-pointer"
                  >
                    Fill Admin 1
                  </button>
                </div>
                <div className="grid grid-cols-2 gap-2 text-[11px]">
                  <div>
                    <span className="text-slate-500 block">ID / Email:</span>
                    <span className="font-mono text-slate-300 truncate block">mahendhra2005@gamil.com</span>
                    <span className="text-[10px] text-slate-500 font-mono">PTS-CEO-001 / Mahendhra</span>
                  </div>
                  <div>
                    <span className="text-slate-500 block">Password:</span>
                    <span className="font-mono text-slate-300">ydm@1962</span>
                  </div>
                </div>

                {/* Admin 2 */}
                <div className="flex items-center justify-between pt-2 pb-1.5 border-t border-b border-slate-800/70">
                  <span className="text-[11px] text-slate-300 font-medium">Admin 2: P Praveen Kumar (COO)</span>
                  <button
                    type="button"
                    onClick={fillTestAdmin2}
                    className="text-[11px] font-semibold text-indigo-400 hover:text-indigo-300 transition cursor-pointer"
                  >
                    Fill Admin 2
                  </button>
                </div>
                <div className="grid grid-cols-2 gap-2 text-[11px]">
                  <div>
                    <span className="text-slate-500 block">ID / Email:</span>
                    <span className="font-mono text-slate-300 truncate block">praveenpraba399@gamil.com</span>
                    <span className="text-[10px] text-slate-500 font-mono">PTS-COO-001 / Praveen</span>
                  </div>
                  <div>
                    <span className="text-slate-500 block">Password:</span>
                    <span className="font-mono text-slate-300">ydm@1962</span>
                  </div>
                </div>

                {/* Sample Intern */}
                <div className="flex items-center justify-between pt-2 border-t border-slate-800/70">
                  <span className="text-[11px] text-slate-400 font-medium">Intern Account (Sample)</span>
                  <button
                    type="button"
                    onClick={fillTestIntern}
                    className="text-[11px] font-semibold text-indigo-400 hover:text-indigo-300 transition cursor-pointer"
                  >
                    Fill Intern
                  </button>
                </div>
                <div className="grid grid-cols-2 gap-2 text-[11px]">
                  <div>
                    <span className="text-slate-500 block">Intern ID:</span>
                    <span className="font-mono text-slate-300">INT-2024-01</span>
                  </div>
                  <div>
                    <span className="text-slate-500 block">Password:</span>
                    <span className="font-mono text-slate-300">intern123</span>
                  </div>
                </div>
              </div>
            )}
          </div>

        </div>
      </main>

      {/* Forgot Password Modal */}
      {forgotModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm">
          <div className="w-full max-w-sm bg-slate-900 border border-slate-800 rounded-xl p-6 shadow-2xl space-y-4">
            <h3 className="text-base font-semibold text-white">Reset Password</h3>
            <p className="text-xs text-slate-400">
              Enter your registered ID or email. An administrator notification and reset link will be dispatched.
            </p>

            {forgotSent ? (
              <div className="p-3 bg-emerald-950/60 border border-emerald-800 text-emerald-300 rounded-lg text-xs flex items-center gap-2">
                <CheckCircle className="w-4 h-4 shrink-0 text-emerald-400" />
                <span>Password reset notice dispatched successfully!</span>
              </div>
            ) : (
              <form onSubmit={handleForgotPassword} className="space-y-3">
                <input
                  type="text"
                  value={forgotEmail}
                  onChange={(e) => setForgotEmail(e.target.value)}
                  required
                  placeholder="Enter User ID or Email"
                  className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-lg text-sm text-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
                />
                <div className="flex items-center justify-end gap-2 pt-2">
                  <button
                    type="button"
                    onClick={() => setForgotModalOpen(false)}
                    className="px-3 py-1.5 text-xs text-slate-400 hover:text-white rounded"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    className="px-3 py-1.5 text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-500 rounded"
                  >
                    Send Reset Link
                  </button>
                </div>
              </form>
            )}
          </div>
        </div>
      )}

      {/* Footer */}
      <footer className="border-t border-slate-800/80 py-4 px-6 text-center text-xs text-slate-500">
        Phoenix Tech Solutions · Enterprise Project & Intern Management Platform
      </footer>
    </div>
  );
};
